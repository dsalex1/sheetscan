# flake8: noqa: S101

import math
import xml.etree.ElementTree as ET
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass
from fractions import Fraction

import numpy as np

from homr import constants
from homr.simple_logging import eprint
from homr.transformer.vocabulary import (
    EncodedSymbol,
    SymbolDuration,
    empty,
    is_lower_position,
    nonote,
    sort_token_chords,
)


class ConversionState:
    def __init__(self, division: int, nominator: Fraction):
        self.beats = 4 * constants.duration_of_quarter
        self.division = division
        self.nominator = nominator
        self.tremolo_state = "stop"
        self.volta_number = 1
        self.last_volta_measure = -10

    def start_volta(self, measure_no: int) -> int:
        if measure_no == self.last_volta_measure + 1:
            self.volta_number += 1
        else:
            self.volta_number = 1
        return self.volta_number

    def stop_volta(self, measure_no: int) -> int:
        self.last_volta_measure = measure_no
        return self.volta_number

    def toggle_tremolo_state(self) -> str:
        if self.tremolo_state == "start":
            self.tremolo_state = "stop"
        else:
            self.tremolo_state = "start"
        return self.tremolo_state


class SymbolChord:
    def __init__(
        self, symbols: list[EncodedSymbol], tuplet_marks: dict[str, str] | None = None
    ) -> None:
        self.symbols = symbols
        # Tuplet start or stop by position (e.g. upper2), voices have their own tuplets
        self.tuplet_marks: dict[str, str] = tuplet_marks if tuplet_marks is not None else {}

    def mark_for(self, symbol: EncodedSymbol) -> str:
        return self.tuplet_marks.get(symbol.position, "")

    def __str__(self) -> str:
        return str.join("&", [str(s) for s in self.symbols])

    def __repr__(self) -> str:
        return str(self)

    def is_barline(self) -> bool:
        if len(self.symbols) == 0:
            return False
        first_rhythm = self.symbols[0].rhythm
        return "barline" in first_rhythm or "repeat" in first_rhythm

    def get_duration(self) -> Fraction:
        notes_rests = [
            s.get_duration().fraction for s in self.symbols if s.rhythm.startswith(("note", "rest"))
        ]
        if len(notes_rests) == 0:
            return Fraction(0)
        return min(notes_rests)

    def into_positions(self) -> list["SymbolChord"]:
        buckets: dict[str, list[EncodedSymbol]] = defaultdict(list)
        for symbol in self.symbols:
            buckets[symbol.position].append(symbol)
        chords = [SymbolChord(symbols, self.tuplet_marks) for symbols in buckets.values()]
        # Voices of only rests go first, the last chord is the one which advances time.
        chords.sort(
            key=lambda chord: all(s.rhythm.startswith("rest") for s in chord.symbols), reverse=True
        )
        return chords


class XmlGeneratorArguments:
    def __init__(
        self, large_page: bool | None = None, metronome: int | None = None, tempo: int | None = None
    ):
        self.large_page = large_page
        self.metronome = metronome
        self.tempo = tempo


def build_identification() -> ET.Element:
    ident = ET.Element("identification")
    enc = ET.SubElement(ident, "encoding")
    ET.SubElement(enc, "software").text = "homr"
    return ident


def generate_xml(
    args: XmlGeneratorArguments, staffs: list[list[EncodedSymbol]], title: str
) -> ET.Element:
    root = ET.Element("score-partwise", version="4.0")
    root.append(build_work(title))
    root.append(build_identification())
    root.append(build_defaults(args))
    has_two_staves_by_part = [_voice_has_two_staves(staff) for staff in staffs]
    root.append(build_part_list(has_two_staves_by_part))
    for index, staff in enumerate(staffs):
        root.append(build_part(args, staff, index, has_two_staves_by_part[index]))
    return root


def xml_to_string(element: ET.Element) -> str:
    return ET.tostring(element, encoding="unicode")


def _voice_has_two_staves(voice: list[EncodedSymbol]) -> bool:
    """True if any symbol uses the lower staff (e.g. piano left hand / bass clef)."""
    return any(is_lower_position(s.position) for s in voice)


def build_part(
    args: XmlGeneratorArguments, voice: list[EncodedSymbol], index: int, has_two_staves: bool
) -> ET.Element:
    part = ET.Element("part", id=get_part_id(index))
    is_first_part = index == 0
    for measure in build_measures(args, voice, is_first_part, has_two_staves):
        part.append(measure)
    convert_ties(part)
    add_stems(part)
    _remove_position_attributes(part)
    return part


def build_measures(
    args: XmlGeneratorArguments,
    voice: list[EncodedSymbol],
    is_first_part: bool,
    has_two_staves: bool = False,
) -> list[ET.Element]:
    clock = GroupClock()
    measure_number = 1
    # Measures a multi-measure rest still covers after the current one
    rest_measures = 0

    def measure_rests(measure: ET.Element) -> None:
        positions = ["upper", "lower"] if has_two_staves else ["upper"]
        for staff_no, position in enumerate(positions):
            if staff_no > 0:
                measure.append(build_backup(state.nominator, state))
            measure.append(
                build_measure_rest(EncodedSymbol("measureRest", position=position), state)
            )

    def close_current_measure() -> None:
        nonlocal clock, measure_number, rest_measures
        rebalance_measure_voices(current_measure)
        measures.append(current_measure)
        clock = GroupClock()
        # MusicXML writes a multi-measure rest as that many measures
        for _ in range(rest_measures):
            measure_number += 1
            measure = ET.Element("measure", number=str(measure_number))
            measure_rests(measure)
            measures.append(measure)
        rest_measures = 0

    groups = split_mixed_chords(add_tuplet_start_stop(group_into_chords(voice)))
    division, nominators = find_division_and_time_signature_nominators(groups)
    state = ConversionState(division, nominators[0])
    time_signature_no = 0
    measures: list[ET.Element] = []
    current_measure = ET.Element("measure", number=str(measure_number))
    first_attributes = build_or_get_attributes(current_measure, None)
    ET.SubElement(first_attributes, "divisions").text = str(division // 4)
    if has_two_staves:
        ET.SubElement(first_attributes, "staves").text = "2"
        ET.SubElement(first_attributes, "part-symbol").text = "brace"
    if is_first_part:
        direction = build_add_time_direction(args)
        if direction is not None:
            current_measure.append(direction)
    attributes: ET.Element | None = first_attributes
    for group_no, group in enumerate(groups):
        symbol = group.symbols[0]
        rhythm = symbol.rhythm
        last_attributes = attributes
        attributes = None
        if rhythm.startswith(("note", "rest")):
            if len(group.symbols) == 1 and rhythm.endswith("m"):
                attributes = build_or_get_attributes(current_measure, last_attributes)
                duration = build_multi_measure_rest(symbol, attributes)
                if duration > 0:
                    measure_rests(current_measure)
                    rest_measures = duration - 1
            else:
                staff_positions = group.into_positions()
                gap = clock.wait_for_voices(group)
                if gap > 0:
                    current_measure.append(build_forward(gap, state))
                advance = clock.advance(group)
                for pos_no, staff_pos in enumerate(staff_positions):
                    chord_duration = advance if pos_no == len(staff_positions) - 1 else Fraction(0)
                    for note_xml in build_note_chord(staff_pos, state, chord_duration):
                        current_measure.append(note_xml)
            continue
        if rhythm == "measureRest":
            for staff_no, rest in enumerate(sorted(group.symbols, key=get_staff)):
                if staff_no > 0:
                    current_measure.append(build_backup(state.nominator, state))
                current_measure.append(build_measure_rest(rest, state))
        elif rhythm == "newline":
            is_last_measure = group_no == len(groups) - 1
            if not is_last_measure:
                ET.SubElement(current_measure, "print", attrib={"new-system": "yes"})
        elif rhythm.startswith("clef"):
            attributes = build_or_get_attributes(current_measure, last_attributes, force_new=True)
            for should_be_clef in group.symbols:
                if should_be_clef.rhythm.startswith("clef"):
                    build_clef(should_be_clef, attributes)
        elif rhythm.startswith("keySignature"):
            attributes = build_or_get_attributes(current_measure, last_attributes)
            build_key(symbol, attributes)
        elif rhythm.startswith("timeSignature"):
            attributes = build_or_get_attributes(current_measure, last_attributes)
            state.nominator = nominators[min(time_signature_no, len(nominators) - 1)]
            time_signature_no += 1
            build_time_signature(symbol, attributes, state)
        elif "barline" in rhythm:
            if rhythm != "barline":
                barline = build_or_get_barline(current_measure, "right")
                build_barline_style(symbol, barline)

            close_current_measure()
            measure_number += 1
            current_measure = ET.Element("measure", number=str(measure_number))
        elif rhythm == "repeatStart":
            close_current_measure()
            measure_number += 1
            current_measure = ET.Element("measure", number=str(measure_number))

            barline = build_or_get_barline(current_measure, "right")
            build_repeat(symbol, barline)
        elif rhythm == "repeatEnd":
            barline = build_or_get_barline(current_measure, "right")
            build_repeat(symbol, barline)

            close_current_measure()
            measure_number += 1
            current_measure = ET.Element("measure", number=str(measure_number))
        elif rhythm == "repeatEndStart":
            barline = build_or_get_barline(current_measure, "right")
            build_repeat(EncodedSymbol("repeatEnd"), barline)

            close_current_measure()
            measure_number += 1
            current_measure = ET.Element("measure", number=str(measure_number))
            barline = build_or_get_barline(current_measure, "right")
            build_repeat(EncodedSymbol("repeatStart"), barline)
        elif rhythm.startswith("voltaStart"):
            volta_number = state.start_volta(measure_number)
            barline = build_or_get_barline(current_measure, "left")
            build_barline_ending(symbol, barline, volta_number)
        elif rhythm.startswith(("voltaStop", "voltaDiscontinue")):
            volta_number = state.stop_volta(measure_number)
            barline = build_or_get_barline(current_measure, "right")
            build_barline_ending(symbol, barline, volta_number)

        elif rhythm.startswith("dynamic") or symbol.articulation.startswith("dynamic"):
            for dynamic in group.symbols:
                build_dynamic(dynamic, current_measure)
        else:
            eprint("Symbol isn't supported yet ", symbol)

    if len(list(current_measure)) > 0:
        close_current_measure()
    # A clef opens a second attributes element, so look at the whole first measure
    if measures[0].find("attributes/time") is None:
        time_el = ET.SubElement(first_attributes, "time")
        beats = max(int(state.nominator * 4), 1)
        ET.SubElement(time_el, "beats").text = str(beats)
        ET.SubElement(time_el, "beat-type").text = "4"
    return measures


class GroupClock:
    """
    When the groups of a measure start. Tokens say which notes start together, not
    when each group starts. A group starts when the earliest still-sounding note ends
    (that is how training data is grouped), but not before the earlier notes of its
    own positions (voices) have ended.
    """

    def __init__(self) -> None:
        self.time = Fraction(0)
        self.sounding: list[Fraction] = []
        self.voice_free: dict[str, Fraction] = {}

    @staticmethod
    def _timed(group: SymbolChord) -> list[EncodedSymbol]:
        # Grace notes have no duration and take no time
        return [
            s
            for s in group.symbols
            if s.rhythm.startswith(("note", "rest")) and s.get_duration().fraction > 0
        ]

    def wait_for_voices(self, group: SymbolChord) -> Fraction:
        """Moves the time to when the positions of the group are free, returns the gap."""
        free = max(
            (self.voice_free.get(s.position, Fraction(0)) for s in self._timed(group)),
            default=Fraction(0),
        )
        gap = max(free - self.time, Fraction(0))
        self.time += gap
        self.sounding = [end for end in self.sounding if end > self.time]
        return gap

    def advance(self, group: SymbolChord) -> Fraction:
        """Moves the time to the start of the next group and returns how far."""
        # A position can hold notes of different lengths, the shortest one frees it
        shortest: dict[str, Fraction] = {}
        for symbol in self._timed(group):
            duration = symbol.get_duration().fraction
            shortest[symbol.position] = min(duration, shortest.get(symbol.position, duration))
        for position, duration in shortest.items():
            self.voice_free[position] = self.time + duration
        advance = _advance_to_next_group(group, self.time, self.sounding)
        self.time += advance
        self.sounding = [end for end in self.sounding if end > self.time]
        return advance


def _advance_to_next_group(
    group: SymbolChord, clock: Fraction, sounding: list[Fraction]
) -> Fraction:
    """How far the next group starts after this one, updating the sounding notes in place."""
    durations = [
        s.get_duration().fraction for s in group.symbols if s.rhythm.startswith(("note", "rest"))
    ]
    timed = [d for d in durations if d > 0]  # grace notes have no duration and take no time
    if not timed:
        return Fraction(0)
    sounding.extend(clock + d for d in timed)
    return min(end for end in sounding if end > clock) - clock


def build_work(title_text: str) -> ET.Element:
    work = ET.Element("work")
    ET.SubElement(work, "work-title").text = title_text
    return work


def build_defaults(args: XmlGeneratorArguments) -> ET.Element:
    defaults = ET.Element("defaults")
    if args.large_page:
        page_layout = ET.SubElement(defaults, "page-layout")
        ET.SubElement(page_layout, "page-height").text = "300"
        ET.SubElement(page_layout, "page-width").text = "110"
    return defaults


def get_part_id(index: int) -> str:
    return "P" + str(index + 1)


def _part_metadata(has_two_staves: bool) -> tuple[str, str, str, int]:
    """Return (part_name, instrument_name, instrument_sound, midi_program) for a part.

    We classify by staff layout only:
    - single-staff parts -> Voice
    - two-staff parts -> Piano
    midi_program is 1-based (MusicXML: 1-128; 1 = Acoustic Grand Piano, 54 = Voice Oohs).
    """
    if has_two_staves:
        return ("Piano", "Piano", "keyboard.piano", 1)
    return ("Voice", "Voice", "voice", 54)


def build_part_list(has_two_staves_by_part: list[bool]) -> ET.Element:
    part_list = ET.Element("part-list")
    for part, has_two_staves in enumerate(has_two_staves_by_part):
        part_id = get_part_id(part)
        part_name_str, instrument_name_str, instrument_sound_str, midi_program = _part_metadata(
            has_two_staves
        )
        score_part = ET.SubElement(part_list, "score-part", id=part_id)
        ET.SubElement(score_part, "part-name").text = part_name_str
        score_instrument = ET.SubElement(score_part, "score-instrument", id=part_id + "-I1")
        ET.SubElement(score_instrument, "instrument-name").text = instrument_name_str
        ET.SubElement(score_instrument, "instrument-sound").text = instrument_sound_str
        midi_instrument = ET.SubElement(score_part, "midi-instrument", id=part_id + "-I1")
        ET.SubElement(midi_instrument, "midi-channel").text = str(part + 1)
        ET.SubElement(midi_instrument, "midi-program").text = str(midi_program)
        ET.SubElement(midi_instrument, "volume").text = "100"
        ET.SubElement(midi_instrument, "pan").text = "0"
    return part_list


def build_or_get_attributes(
    measure: ET.Element, last_attributes: ET.Element | None, force_new: bool = False
) -> ET.Element:
    if last_attributes is not None and not force_new:
        return last_attributes
    return ET.SubElement(measure, "attributes")


def build_or_get_barline(measure: ET.Element, location: str) -> ET.Element:
    for child in measure:
        if child.tag == "barline" and child.get("location") == location:
            return child
    return ET.SubElement(measure, "barline", location=location)


def build_dynamic(model_dynamic: EncodedSymbol, measure: ET.Element) -> None:
    marks: list[ET.Element] = []
    if model_dynamic.rhythm.startswith("dynamic"):
        dynamic_name = model_dynamic.rhythm.split("_", 1)[1]
        # `dynamic_empty` is the internal placeholder used for a modifier-only
        # marking (for example, "più"). It is not a MusicXML dynamics element.
        if dynamic_name != "empty":
            marks.append(ET.Element(dynamic_name))
    if model_dynamic.articulation.startswith("dynamic"):
        text = ET.Element("other-dynamics")
        text.text = model_dynamic.articulation.split("_", 1)[1].replace("piu", "più")
        marks.append(text)

    if not marks:
        return

    direction = ET.SubElement(measure, "direction", placement="below")
    direction_type = ET.SubElement(direction, "direction-type")
    dynamics = ET.SubElement(direction_type, "dynamics")
    dynamics.extend(marks)

    ET.SubElement(direction, "staff").text = str(get_staff(model_dynamic))


def build_key(model_key: EncodedSymbol, attributes: ET.Element) -> None:
    key = ET.SubElement(attributes, "key")
    ET.SubElement(key, "fifths").text = model_key.rhythm.split("_")[1]


def get_staff(symbol: EncodedSymbol) -> int:
    return 2 if is_lower_position(symbol.position) else 1


def get_xml_voice(staff_num: int, rhythmic_layer: int) -> int:
    """Build a stable MusicXML voice number per staff and rhythmic layer.

    Voice numbers are part-global in MusicXML, so using only the staff number can merge
    independent layers on the same staff. Reserve 4 voices per staff:
    staff 1 -> voices 1-4, staff 2 -> voices 5-8.
    """
    return (staff_num - 1) * 4 + rhythmic_layer + 1


@dataclass
class TimedNoteEvent:
    staff_num: int
    start: int
    end: int
    notes: list[ET.Element]


def rebalance_measure_voices(measure: ET.Element) -> None:
    """Assign stable non-overlapping voices per staff for a whole measure."""
    timed_events: list[TimedNoteEvent] = []
    current_time = 0
    last_note_start = 0
    for child in measure:
        if child.tag == "backup":
            dur = child.find("duration")
            if dur is not None:
                current_time -= int(dur.text)  # type: ignore[arg-type]
            continue
        if child.tag == "forward":
            dur = child.find("duration")
            if dur is not None:
                current_time += int(dur.text)  # type: ignore[arg-type]
            continue
        if child.tag != "note":
            continue

        dur_el = child.find("duration")
        duration = int(dur_el.text) if dur_el is not None else 0  # type: ignore[arg-type]
        staff_el = child.find("staff")
        staff_num = int(staff_el.text) if staff_el is not None else 1  # type: ignore[arg-type]
        is_chord_tone = child.find("chord") is not None
        start = last_note_start if is_chord_tone else current_time
        end = start + duration
        if is_chord_tone and (
            len(timed_events) > 0
            and timed_events[-1].staff_num == staff_num
            and timed_events[-1].start == start
            and timed_events[-1].end == end
        ):
            timed_events[-1].notes.append(child)
        elif is_chord_tone:
            timed_events.append(TimedNoteEvent(staff_num, start, end, [child]))
        else:
            last_note_start = start
            current_time += duration
            timed_events.append(TimedNoteEvent(staff_num, start, end, [child]))

    by_staff: dict[int, list[TimedNoteEvent]] = defaultdict(list)
    for event in timed_events:
        by_staff[event.staff_num].append(event)

    for staff_num, events in by_staff.items():
        sorted_events = sorted(events, key=lambda e: (e.start, e.end))
        active: list[tuple[int, int]] = []
        for event in sorted_events:
            active = [
                (active_end, voice_no)
                for active_end, voice_no in active
                if active_end > event.start
            ]
            used_voices = {voice_no for _, voice_no in active}
            # The second voice of the model (e.g. upper2) prefers the second voice
            voice_no = 2 if _is_second_voice(event.notes[0]) else 1
            if voice_no in used_voices:
                voice_no = 1
                while voice_no in used_voices:
                    voice_no += 1
            active.append((event.end, voice_no))
            xml_voice = str(get_xml_voice(staff_num, voice_no - 1))
            for note in event.notes:
                voice_el = note.find("voice")
                if voice_el is not None:
                    voice_el.text = xml_voice


# The position of the model (e.g. upper2) of a note while the part is built
_POSITION_ATTRIBUTE = "homr-position"


def _is_second_voice(note: ET.Element) -> bool:
    return note.get(_POSITION_ATTRIBUTE, "").endswith("2")


def _remove_position_attributes(part: ET.Element) -> None:
    for note in part.iter("note"):
        note.attrib.pop(_POSITION_ATTRIBUTE, None)


def add_stems(part: ET.Element) -> None:
    """
    Where a staff has two voices in a measure, the first voice has its stems up
    and the second one down. Other stems are left to the reader.
    """
    for measure in part.findall("measure"):
        notes = [n for n in measure.findall("note") if n.find("rest") is None]
        for staff in {n.findtext("staff", "1") for n in notes}:
            on_staff = [n for n in notes if n.findtext("staff", "1") == staff]
            voices = {_is_second_voice(n) for n in on_staff if n.get(_POSITION_ATTRIBUTE)}
            if len(voices) < 2:
                continue
            for note in on_staff:
                stem = ET.Element("stem")
                stem.text = "down" if _is_second_voice(note) else "up"
                staff_el = note.find("staff")
                position = list(note).index(staff_el) if staff_el is not None else len(note)
                note.insert(position, stem)


def get_note_pitch(note: ET.Element) -> str | None:
    pitch = note.find("pitch")
    if pitch is None:
        return None
    return "|".join(pitch.findtext(part, "") for part in ("step", "alter", "octave"))


def get_slur(note: ET.Element, slur_type: str) -> tuple[ET.Element, ET.Element] | None:
    """The note's slur of this type with the notations holding it, if any.

    build_slurs writes at most one start and one stop per note, so there is
    never a choice to make here.
    """
    for notation in note.findall("notations"):
        for slur in notation.findall("slur"):
            if slur.get("type") == slur_type:
                return slur, notation
    return None


def add_tie(note: ET.Element, tie_type: str, notation: ET.Element) -> None:
    """A tie needs both elements: <tie> for what sounds, <tied> for what is drawn."""
    tie = ET.Element("tie", type=tie_type)
    duration = note.find("duration")
    position = list(note).index(duration) + 1 if duration is not None else 0
    note.insert(position, tie)
    notation.insert(0, ET.Element("tied", type=tie_type))


def convert_ties(part: ET.Element) -> None:
    """Rewrite slurs which are really ties, over a whole part.

    The model learns slurs and ties as one class on purpose, so a tie reaches
    us as a slur. A slur is a tie when it joins a note to the very next note
    of its own voice and both carry the same pitch.

    Deliberately no attempt to pair slur starts with slur stops. The slur
    number is the staff number, so several slurs open on one staff share a
    number and cannot be told apart by it — four at once on a test file — and
    any pairing rule would be guessing. A tie needs no pairing: it is a
    property of a note and its immediate successor.

    Run per part rather than per measure, because ties cross barlines. One
    pass is enough: the last event seen in a voice is by definition the
    predecessor of the next one in it.
    """
    previous: dict[tuple[str, str], list[ET.Element]] = {}
    for measure in part.findall("measure"):
        for event in group_into_events(measure):
            first = event[0]
            key = (first.findtext("staff", "1"), first.findtext("voice", "1"))
            before = previous.get(key)
            previous[key] = event
            if before is None:
                continue
            tie_event(before, event)


def group_into_events(measure: ET.Element) -> list[list[ET.Element]]:
    """The measure's notes, with each chord kept together as one event.

    A chord is one moment of the music, not several: <chord> means "sounds
    with the note before". Walking notes one at a time makes a chord's own
    members each other's neighbours, so nothing in a chord ever finds the note
    it is really adjacent to, and no tie between two chords is ever seen.
    """
    events: list[list[ET.Element]] = []
    for note in measure.findall("note"):
        if note.find("chord") is not None and events:
            events[-1].append(note)
        else:
            events.append([note])
    return events


def tie_event(before: list[ET.Element], after: list[ET.Element]) -> None:
    """Convert every slur between two adjacent events that is really a tie.

    Matched by pitch, and led by the slurs: the model marks the notehead the
    curve touches, which on a chord is one member and not the whole thing -
    of the chords carrying a slur on my test material, 25 of 26 had it on
    some members only. So each slurred note looks for its own pitch in the
    next event rather than the chord being taken as a whole.
    """
    for start_note in before:
        begins = get_slur(start_note, "start")
        if begins is None:
            continue
        pitch = get_note_pitch(start_note)
        if pitch is None:
            continue
        for stop_note in after:
            if get_note_pitch(stop_note) != pitch:
                continue
            ends = get_slur(stop_note, "stop")
            if ends is None:
                continue
            begin_slur, begin_notation = begins
            end_slur, end_notation = ends
            begin_notation.remove(begin_slur)
            end_notation.remove(end_slur)
            add_tie(start_note, "start", begin_notation)
            add_tie(stop_note, "stop", end_notation)
            break


def build_clef(model_clef: EncodedSymbol, attributes: ET.Element) -> None:
    sign_and_line = model_clef.rhythm.split("_")[1]
    clef = ET.SubElement(attributes, "clef", number=str(get_staff(model_clef)))
    ET.SubElement(clef, "sign").text = sign_and_line[0]
    ET.SubElement(clef, "line").text = sign_and_line[1]


def build_time_signature(
    model_time_signature: EncodedSymbol, attributes: ET.Element, state: ConversionState
) -> None:
    time = ET.SubElement(attributes, "time")
    denominator = model_time_signature.rhythm.split("/")[1]
    beats = max(int(state.nominator * int(denominator)), 1)
    ET.SubElement(time, "beats").text = str(beats)
    ET.SubElement(time, "beat-type").text = denominator
    state.beats = beats


def build_barline_style(barline: EncodedSymbol, xml: ET.Element) -> None:
    style_value = "heavy-heavy" if barline.rhythm == "bolddoublebarline" else "light-light"
    ET.SubElement(xml, "bar-style").text = style_value


def build_barline_ending(volta: EncodedSymbol, xml: ET.Element, volta_number: int) -> None:
    if volta.rhythm.startswith("voltaStart"):
        type_ = "start"
    elif volta.rhythm.startswith("voltaStop"):
        type_ = "stop"
    elif volta.rhythm.startswith("voltaDiscontinue"):
        type_ = "discontinue"
    else:
        raise ValueError("Unknown ending " + str(volta))
    ET.SubElement(xml, "ending", type=type_, number=str(volta_number))


def build_repeat(barline: EncodedSymbol, xml: ET.Element) -> None:
    if xml.find("repeat") is not None:
        eprint("barline already has a repeat")
        return
    direction = "forward" if barline.rhythm == "repeatStart" else "backward"
    ET.SubElement(xml, "repeat", direction=direction)


LIFT_TO_ALTER = {
    "N": 0,
    "#": 1,
    "##": 2,
    "b": -1,
    "bb": -2,
}

DURATION_NAMES = {
    0: "breve",
    1: "whole",
    2: "half",
    4: "quarter",
    8: "eighth",
    16: "16th",
    32: "32nd",
    64: "64th",
    128: "128th",
}


def build_articulations(
    note: ET.Element, articualations: str, tuplet_mark: str, state: ConversionState
) -> None:
    notation = ET.SubElement(note, "notations")

    xml_articulations: list[ET.Element] = []
    xml_ornaments: list[ET.Element] = []
    if not articualations.startswith("dynamic"):
        for articulation in articualations.split("_"):
            if articulation == "":
                continue
            elif articulation == nonote:
                eprint("WARNING note without valid articulation", articualations)
            elif articulation == "fermata":
                ET.SubElement(notation, "fermata")
            elif articulation == "arpeggiate":
                ET.SubElement(notation, "arpeggiate")
            elif articulation == "accent":
                xml_articulations.append(ET.Element("accent"))
            elif articulation == "accentStrong":
                xml_articulations.append(ET.Element("strong-accent"))
            elif articulation == "mordent":
                xml_articulations.append(ET.Element("mordent"))
            elif articulation == "staccato":
                xml_articulations.append(ET.Element("staccato"))
            elif articulation == "staccatissimo":
                xml_articulations.append(ET.Element("staccatissimo"))
            elif articulation == "tenuto":
                xml_articulations.append(ET.Element("tenuto"))
            elif articulation == "tremolo":
                el = ET.Element("tremolo", type=state.toggle_tremolo_state())
                el.text = "3"
                xml_ornaments.append(el)
            elif articulation == "trill":
                xml_ornaments.append(ET.Element("trill-mark"))
            elif articulation == "breathMark":
                xml_articulations.append(ET.Element("breath-mark"))
            elif articulation == "turn":
                xml_ornaments.append(ET.Element("inverted-turn"))
            elif articulation == "caesura":
                xml_articulations.append(ET.Element("caesura"))
            elif articulation == "doit":
                xml_articulations.append(ET.Element("doit"))
            elif articulation == "slurStart":
                ET.SubElement(notation, "slur", type="start")
            elif articulation == "slurStop":
                ET.SubElement(notation, "slur", type="stop")
            elif articulation == "tieStart":
                ET.SubElement(notation, "tied", type="start")
            elif articulation == "tieStop":
                ET.SubElement(notation, "tied", type="stop")
            else:
                raise ValueError("Unsupported articulation " + articulation)

    for mark in tuplet_mark.split("_"):
        if mark:
            ET.SubElement(notation, "tuplet", type=mark)

    if xml_articulations:
        parent = ET.SubElement(notation, "articulations")
        for child in xml_articulations:
            parent.append(child)

    if xml_ornaments:
        parent = ET.SubElement(notation, "ornaments")
        for child in xml_ornaments:
            parent.append(child)


def build_slurs(note: ET.Element, slurs: str, slur_number: int) -> None:
    notation = note.find("notations")
    if notation is None:
        notation = ET.SubElement(note, "notations")

    if slurs in {"_", ""}:
        pass
    elif slurs == nonote:
        eprint("WARNING note without valid articulation", slurs)
    elif slurs == "slurStart":
        ET.SubElement(notation, "slur", type="start", number=str(slur_number))
    elif slurs == "slurStop":
        ET.SubElement(notation, "slur", type="stop", number=str(slur_number))
    elif slurs == "slurStart_slurStop":
        ET.SubElement(notation, "slur", type="stop", number=str(slur_number))
        ET.SubElement(notation, "slur", type="start", number=str(slur_number))
    else:
        raise ValueError("Unsupported slur " + slurs)


def build_note_or_rest(
    model_note: EncodedSymbol,
    rhythmic_layer: int,
    is_chord: bool,
    state: ConversionState,
    tuplet_mark: str,
) -> ET.Element:
    note = ET.Element("note")
    if is_chord:
        ET.SubElement(note, "chord")
    model_pitch = model_note.pitch
    model_duration = model_note.get_duration()

    if "G" in model_note.rhythm:
        ET.SubElement(note, "grace")

    if model_pitch == empty:
        if model_duration.fraction.numerator == 0:
            ET.SubElement(note, "rest", measure="yes")
        else:
            ET.SubElement(note, "rest")
    elif model_pitch == nonote:
        eprint("WARNING note without pitch", model_note)
        ET.SubElement(note, "rest")
    else:
        pitch = ET.SubElement(note, "pitch")
        ET.SubElement(pitch, "step").text = model_pitch[0]
        ET.SubElement(pitch, "octave").text = model_pitch[1]
        if model_note.lift == nonote:
            eprint("WARNING note with invalid lift", model_note)
        elif model_note.lift != empty:
            ET.SubElement(pitch, "alter").text = str(LIFT_TO_ALTER[model_note.lift])

    if "G" in model_note.rhythm:
        base_duration = model_duration.kern
        ET.SubElement(note, "type").text = DURATION_NAMES[base_duration]
    elif model_duration.fraction.numerator > 0:
        base_duration = 1 if model_duration.kern == 0 else model_duration.kern
        ET.SubElement(note, "duration").text = str(
            max(1, int(model_duration.fraction * state.division))
        )
        ET.SubElement(note, "type").text = DURATION_NAMES[base_duration]
    else:
        ET.SubElement(note, "duration").text = str(state.beats)
        ET.SubElement(note, "type").text = DURATION_NAMES[0]

    for _ in range(model_duration.dots):
        ET.SubElement(note, "dot")

    if model_duration.actual_notes != model_duration.normal_notes:
        time_mod = ET.SubElement(note, "time-modification")
        ET.SubElement(time_mod, "actual-notes").text = str(model_duration.actual_notes)
        ET.SubElement(time_mod, "normal-notes").text = str(model_duration.normal_notes)

    staff_num = get_staff(model_note)
    slur_number = staff_num
    ET.SubElement(note, "voice").text = str(get_xml_voice(staff_num, rhythmic_layer))
    ET.SubElement(note, "staff").text = str(staff_num)
    # Used for voices and stems, removed at the end of build_part
    note.set(_POSITION_ATTRIBUTE, model_note.position)

    # The other notes of a group, e.g. in the other staff, aren't part of the tuplet
    is_tuplet = model_duration.actual_notes != model_duration.normal_notes
    build_articulations(note, model_note.articulation, tuplet_mark if is_tuplet else "", state)
    build_slurs(note, model_note.slur, slur_number)
    build_image_position(note, model_note)

    return note


def build_image_position(xml: ET.Element, symbol: EncodedSymbol) -> None:
    """
    Adds the position of the symbol on the input image as comment. The position is estimated
    from the attention of the transformer, it points roughly at the symbol but isn't precise.
    """
    if symbol.image_coordinates is None:
        return
    x, y = symbol.image_coordinates
    xml.append(ET.Comment(f" imgpos: {round(x)}, {round(y)} "))


def build_multi_measure_rest(symbol: EncodedSymbol, attributes: ET.Element) -> int:
    """Returns the number of measures of the rest, 0 if the measure already has one."""
    if attributes.find("measure-style") is not None:
        eprint("Measure already has a multi rest")
        return 0
    duration = int(symbol.rhythm.split("_")[1].replace("m", ""))
    style = ET.SubElement(attributes, "measure-style")
    ET.SubElement(style, "multiple-rest").text = str(duration)
    return duration


def build_measure_rest(symbol: EncodedSymbol, state: ConversionState) -> ET.Element:
    """A rest which fills the measure, e.g. in a staff which is hidden in a system."""
    note = ET.Element("note")
    ET.SubElement(note, "rest", measure="yes")
    duration = max(1, int(state.nominator * state.division))
    ET.SubElement(note, "duration").text = str(duration)
    ET.SubElement(note, "voice").text = "1"
    ET.SubElement(note, "staff").text = str(get_staff(symbol))
    return note


def build_forward(duration: Fraction, state: ConversionState) -> ET.Element:
    forward = ET.Element("forward")
    ET.SubElement(forward, "duration").text = str(max(1, int(duration * state.division)))
    return forward


def build_backup(duration: Fraction, state: ConversionState) -> ET.Element:
    assert duration > Fraction(0), "Backup duration must be positive"
    backup = ET.Element("backup")
    ET.SubElement(backup, "duration").text = str(max(1, int(duration * state.division)))
    return backup


def build_note_chord(
    note_chord: SymbolChord, state: ConversionState, chord_duration: Fraction
) -> list[ET.Element]:
    by_duration = _group_notes(note_chord.symbols)
    result: list[ET.Element] = []
    for i, (group_duration, group_notes) in enumerate(by_duration.items()):
        notes = [n for n in group_notes if n.pitch not in (empty, nonote)]
        rests = [n for n in group_notes if n.pitch in (empty, nonote)]

        is_first = True
        for note in notes:
            result.append(
                build_note_or_rest(note, i, not is_first, state, note_chord.mark_for(note))
            )
            is_first = False

        # A grace note without pitch would be a rest which takes no time
        if rests and group_duration > Fraction(0):
            if notes:
                # There are other notes, so to avoid rest being merged into chord, we emit a backup
                result.append(build_backup(group_duration, state))
            # Ideally we expect len(rests) == 1, but in dataset we see cases where
            # there are multiple rests. So here we just take the first rest
            result.append(
                build_note_or_rest(rests[0], i, False, state, note_chord.mark_for(rests[0]))
            )

        if i != len(by_duration) - 1 and group_duration > Fraction(0):
            result.append(build_backup(group_duration, state))

    if chord_duration < max(by_duration):
        result.append(build_backup(max(by_duration) - chord_duration, state))

    return result


def _group_notes(notes: list[EncodedSymbol]) -> dict[Fraction, list[EncodedSymbol]]:
    groups_by_duration = defaultdict(list)
    max_duration = max([n.get_duration().fraction for n in notes])
    for note in notes:
        duration = note.get_duration()
        is_grace = "G" in note.rhythm
        if is_grace:
            fraction = Fraction(0)
        elif duration.fraction.numerator == 0:
            fraction = max_duration
        else:
            fraction = duration.fraction
        groups_by_duration[fraction].append(note)
    return dict(sorted(groups_by_duration.items()))


def build_add_time_direction(args: XmlGeneratorArguments) -> ET.Element | None:
    if not args.metronome:
        return None
    direction = ET.Element("direction")
    direction_type = ET.SubElement(direction, "direction-type")
    metronome = ET.SubElement(direction_type, "metronome")
    ET.SubElement(metronome, "beat-unit").text = "quarter"
    ET.SubElement(metronome, "per-minute").text = str(args.metronome)
    tempo = args.tempo if args.tempo else args.metronome
    ET.SubElement(direction, "sound", tempo=str(tempo))
    return direction


def find_common_division(durations: list[Fraction]) -> int:
    """
    Find the smallest division (denominator) so that all durations
    can be expressed as integer multiples.
    """

    def lcm(a: int, b: int) -> int:
        return abs(a * b) // math.gcd(a, b)

    denominators = [d.denominator for d in durations if d > 0]
    if not denominators:
        return 1
    common = denominators[0]
    for d in denominators[1:]:
        common = lcm(common, d)
    return common


def find_division_and_time_signature_nominators(
    voice: list[SymbolChord],
) -> tuple[int, list[Fraction]]:
    """
    Returns the division and one measure length per time signature, estimated from the
    measures up to the next time signature. Measures before the first one count towards it.
    """
    durations = [Fraction(1, 4)]
    duration_in_measure = Fraction(0)
    segments: list[list[Fraction]] = [[]]
    has_time_signature = False
    for chord in voice:
        if chord.symbols and chord.symbols[0].rhythm.startswith("timeSignature"):
            if duration_in_measure > Fraction(0):
                segments[-1].append(duration_in_measure)
                duration_in_measure = Fraction(0)
            if has_time_signature:
                segments.append([])
            has_time_signature = True
        elif chord.is_barline() and duration_in_measure > Fraction(0):
            segments[-1].append(duration_in_measure)
            duration_in_measure = Fraction(0)
        else:
            for symbol in chord.symbols:
                if symbol.rhythm.startswith(("note", "rest")):
                    frac = symbol.get_duration().fraction
                    if frac > Fraction(0):
                        durations.append(frac)
            duration = chord.get_duration()
            if duration > Fraction(0):
                duration_in_measure += duration

    if duration_in_measure > Fraction(0):
        segments[-1].append(duration_in_measure)

    all_measures = [d for segment in segments for d in segment]
    if len(all_measures) == 0:
        return find_common_division(durations), [Fraction(1)] * len(segments)

    # A time signature without measures after it, e.g. a courtesy one at the end of a
    # system, belongs to the measures of the next one
    nominators: list[Fraction] = []
    following: Fraction = np.median(all_measures)  # type: ignore
    for segment in reversed(segments):
        if segment:
            following = np.median(segment)  # type: ignore
        nominators.append(following)
    nominators.reverse()

    return find_common_division(durations), nominators


_BEFORE_NOTES_ORDER = ["clef", "keySignature", "timeSignature"]


def _split_mixed_chord(symbols: list[EncodedSymbol]) -> list[list[EncodedSymbol]]:
    """
    The transformer sometimes joins a clef, key, time signature or barline to a chord
    of notes, e.g. a clef change in one staff on the beat where the other staff plays.
    build_measures handles a group by its first symbol: if that is a note the extra
    symbol becomes a zero-length rest (and fails an assertion), otherwise the notes
    are dropped. Split it: clefs, keys and time signatures go before the notes (in
    the order they have at the start of a line), barlines and repeats after them.
    """
    notes = [s for s in symbols if s.rhythm.startswith(("note", "rest"))]
    if not notes or len(notes) == len(symbols):
        return [symbols]
    others = [s for s in symbols if not s.rhythm.startswith(("note", "rest"))]
    after = [s for s in others if "barline" in s.rhythm or "repeat" in s.rhythm]
    before: dict[str, list[EncodedSymbol]] = defaultdict(list)
    for s in others:
        if s not in after:
            before[s.rhythm.split("_")[0].split("/")[0]].append(s)
    rank = {kind: i for i, kind in enumerate(_BEFORE_NOTES_ORDER)}
    ordered = sorted(before, key=lambda kind: rank.get(kind, len(rank)))
    return [*(before[kind] for kind in ordered), notes, *([s] for s in after)]


def split_mixed_chords(groups: list[SymbolChord]) -> list[SymbolChord]:
    """
    Applies _split_mixed_chord to every group. Runs after the tuplet marks are set, so
    the notes keep their mark and a split-off clef doesn't interrupt a tuplet.
    """
    result: list[SymbolChord] = []
    split_barline = False
    for group in groups:
        parts = _split_mixed_chord(group.symbols)
        if split_barline and group.is_barline() and len(parts) == 1:
            # The barline split off the previous chord and this one are the same barline:
            # keep one, preferring a repeat or double barline over a plain barline.
            if group.symbols[0].rhythm == "barline" and result[-1].symbols[0].rhythm != "barline":
                split_barline = False
                continue
            result.pop()
        for part in parts:
            is_notes = part[0].rhythm.startswith(("note", "rest"))
            result.append(SymbolChord(part, group.tuplet_marks if is_notes else {}))
        split_barline = len(parts) > 1 and result[-1].is_barline()
    return result


def group_into_chords(voice: list[EncodedSymbol]) -> list[SymbolChord]:
    return [SymbolChord(s) for s in sort_token_chords(voice)]


class TupletParser:
    """
    Marks the start and stop of tuplets, per measure and position. A tuplet ends
    with the note which ends on the beat grid again, e.g. after three eighth
    triplets or a quarter and an eighth triplet. Counting by time rather than by
    notes keeps a voice in phase whose tuplet begins with a rest in another voice.
    Groups without a tuplet note at the position, e.g. a duplet in the other
    staff, are skipped.
    """

    @staticmethod
    def parse(groups: list[SymbolChord]) -> list[SymbolChord]:
        for measure_groups in TupletParser.split_into_measures(groups):
            positions = {
                symbol.position
                for group in measure_groups
                for symbol in group.symbols
                if TupletParser._is_tuplet(symbol)
            }
            for position in sorted(positions):
                TupletParser.add_tuplets(measure_groups, position)
        return groups

    @staticmethod
    def _is_tuplet(symbol: EncodedSymbol) -> bool:
        if not symbol.rhythm.startswith(("note", "rest")) or "G" in symbol.rhythm:
            return False
        duration = symbol.get_duration()
        return duration.normal_notes != duration.actual_notes

    @staticmethod
    def get_duration_at(group: SymbolChord, position: str) -> SymbolDuration | None:
        """
        The duration of the first tuplet note or rest at the position, otherwise of the
        first timed one. None if the position has no timed symbol.
        """
        timed = [
            s
            for s in group.symbols
            if s.position == position
            and s.rhythm.startswith(("note", "rest"))
            and "G" not in s.rhythm
        ]
        tuplets = [s for s in timed if TupletParser._is_tuplet(s)]
        if tuplets:
            return tuplets[0].get_duration()
        if timed:
            return timed[0].get_duration()
        return None

    @staticmethod
    def split_into_measures(groups: list[SymbolChord]) -> list[list[SymbolChord]]:
        measures: list[list[SymbolChord]] = []
        current_measure: list[SymbolChord] = []
        for group in groups:
            current_measure.append(group)
            if group.is_barline():
                measures.append(current_measure)
                current_measure = []
        if current_measure:
            measures.append(current_measure)
        return measures

    @staticmethod
    def start_times(groups: list[SymbolChord]) -> list[Fraction]:
        """When each group of a measure starts, the same way as build_measures counts."""
        clock = GroupClock()
        result: list[Fraction] = []
        for group in groups:
            if any(s.rhythm.startswith(("note", "rest")) for s in group.symbols):
                clock.wait_for_voices(group)
                result.append(clock.time)
                clock.advance(group)
            else:
                result.append(clock.time)
        return result

    @staticmethod
    def add_tuplets(groups: list[SymbolChord], position: str) -> None:
        times = TupletParser.start_times(groups)
        run: list[tuple[int, Fraction, Fraction]] = []  # group, start time and duration
        tuplet_format = (1, 1)
        for index, group in enumerate(groups):
            duration = TupletParser.get_duration_at(group, position)
            if duration is None:
                continue
            current_format = (duration.actual_notes, duration.normal_notes)
            if current_format != tuplet_format and run:
                TupletParser._mark_run(groups, position, run)
                run = []
            tuplet_format = current_format
            if current_format[0] != current_format[1]:
                run.append((index, times[index], duration.fraction))
        if run:
            TupletParser._mark_run(groups, position, run)

    @staticmethod
    def _mark_run(
        groups: list[SymbolChord], position: str, run: list[tuple[int, Fraction, Fraction]]
    ) -> None:
        """
        Splits consecutive tuplet notes of one position into tuplets. A tuplet ends once
        its own notes add up to a duration without a tuplet, e.g. three eighth triplets or
        a quarter and an eighth triplet. That keeps working if an earlier note has a wrong
        length. If that leaves notes over, e.g. if the tuplet starts with a rest in another
        voice, a tuplet ends where it reaches the beat grid instead. Notes which are
        left over form an incomplete tuplet.
        """
        by_length = TupletParser._split(run, lambda start, total, end: total)
        by_grid = TupletParser._split(run, lambda start, total, end: end)
        tuplets, left_over = by_length if len(by_length[1]) <= len(by_grid[1]) else by_grid
        if left_over:
            # An incomplete tuplet, e.g. one note too many, still has tuplet durations
            tuplets.append((left_over[0], left_over[-1]))
        for first, last in tuplets:
            if first == last:
                groups[first].tuplet_marks[position] = "start_stop"
            else:
                groups[first].tuplet_marks[position] = "start"
                groups[last].tuplet_marks[position] = "stop"

    @staticmethod
    def _split(
        run: list[tuple[int, Fraction, Fraction]],
        measure: Callable[[Fraction, Fraction, Fraction], Fraction],
    ) -> tuple[list[tuple[int, int]], list[int]]:
        """The complete tuplets as (first, last) group and the groups left over."""
        tuplets: list[tuple[int, int]] = []
        pending: list[int] = []
        total = Fraction(0)
        for index, start, duration in run:
            pending.append(index)
            total += duration
            if _is_power_of_two(measure(start, total, start + duration).denominator):
                tuplets.append((pending[0], index))
                pending = []
                total = Fraction(0)
        return tuplets, pending


def _is_power_of_two(value: int) -> bool:
    return value > 0 and value & (value - 1) == 0


def add_tuplet_start_stop(groups: list[SymbolChord]) -> list[SymbolChord]:
    return TupletParser.parse(groups)


if __name__ == "__main__":
    import sys

    from training.transformer.training_vocabulary import read_tokens

    file = "tabi_measure.tokens"
    if len(sys.argv) > 1:
        file = sys.argv[1]
    tokens = read_tokens(file)
    xml = generate_xml(XmlGeneratorArguments(True), [tokens], "")
    ET.ElementTree(xml).write(
        file.replace(".tokens", ".musicxml"), encoding="unicode", xml_declaration=True
    )
